import { ApiCall } from '../engine/net/client/base/base_api_call'
import { ReqLogin, ResLogin } from '../protocol/PtlLogin'




export default async function (call: ApiCall<ReqLogin, ResLogin>) {
    // TODO vv
    console.log("接收到客户端的消息,进入回调函数, 消息内容: ", call.req)
    const res : ResLogin = {
        id:1,
        name:123,
        isLogin: true
    }
    call.succ(res)
}


