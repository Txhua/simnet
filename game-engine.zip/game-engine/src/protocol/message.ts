export const enum MsgType {
    MessageS2Client = 1001,
    MessageC2Server,
    MessageS2Server,
    MessageS2Gate,
    MessageG2Server,
}