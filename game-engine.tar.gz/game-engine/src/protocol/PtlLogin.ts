export interface ReqLogin {
    id: number
    name: number
}

export interface ResLogin {
    id: number
    name: number
    isLogin: boolean
}
