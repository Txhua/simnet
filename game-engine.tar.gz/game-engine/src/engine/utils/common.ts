/**
 * sleep 精度毫秒
 * @param ms
 */
export async function sleep(ms: number): Promise<void>
{
    return new Promise((resolve) => setTimeout(resolve, ms));
}