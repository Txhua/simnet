import type { TsrpcConfig } from 'tsrpc-cli'
import path from 'path'

console.log('hello')

export default <TsrpcConfig>{
    proto: [
        {
            ptlDir: 'src/protocol',
            output: 'src/protocol/serviceProto.ts',
            apiDir: 'src/api',
            ptlTemplate: { baseFile: 'src/protocols/base.ts' },
            newApiTemplate: (apiBaseName, apiFileDir, ptlFileDir) =>
                `import { ApiCall } from "tsrpc";//自定义的
import { Req${apiBaseName}, Res${apiBaseName} } from "${path
                    .relative(apiFileDir, ptlFileDir)
                    .replace(/\\/g, '/')}/Ptl${apiBaseName}";

export default async function (call: ApiCall<Req${apiBaseName}, Res${apiBaseName}>) {
    // TODO vv
    call.error('API Not Implemented 。。。。。。。。。。');
}`,
            // msgTemplate: { baseFile: 'src/shared/protocols/base.ts' },
        },
    ],
}
